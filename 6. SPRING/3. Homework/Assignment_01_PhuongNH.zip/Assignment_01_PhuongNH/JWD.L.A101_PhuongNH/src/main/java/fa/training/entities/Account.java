package fa.training.entities;

public class Account {
	private int accountId;
	private String account;
	private String email;
	private String password;
	private boolean status;
	private int employeeId;

	public Account() {
	}

	public Account(int accountId, String account, String email, String password, boolean status, int employeeId) {
		super();
		this.accountId = accountId;
		this.account = account;
		this.email = email;
		this.password = password;
		this.status = status;
		this.employeeId = employeeId;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", account=" + account + ", email=" + email + ", password="
				+ password + ", status=" + status + ", employeeId=" + employeeId + "]";
	}
}
