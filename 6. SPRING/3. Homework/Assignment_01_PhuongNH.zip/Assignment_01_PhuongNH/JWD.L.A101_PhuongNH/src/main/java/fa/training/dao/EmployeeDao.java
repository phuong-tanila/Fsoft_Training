package fa.training.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import fa.training.entities.Employee;
import fa.training.utils.DBUtil;

public class EmployeeDao {

	public List<Employee> getAllEmployees() throws SQLException {
		Connection conn = DBUtil.makeConnection();
		PreparedStatement stm = conn.prepareStatement("SELECT [employee_id]\n" + "      ,[first_name]\n"
				+ "		 ,[last_name]\n" + "      ,[gender]\n" + "      ,[date_of_birth]\n" + "      ,[phone]\n"
				+ "      ,[address]\n" + "      ,[department_name]\n" + "      ,[remark]\n"
				+ "  FROM [JWD_Assignment_01].[dbo].[Employee]");
		ResultSet rs = stm.executeQuery();
		ArrayList<Employee> list = new ArrayList<>();
		while (rs.next()) {
			Employee e = new Employee();
			e.setEmployeeId(rs.getInt("employee_id"));
			e.setFirstName(rs.getString("first_name"));
			e.setLastName(rs.getString("last_name"));
			e.setGender(rs.getBoolean("gender"));
			e.setDob(rs.getDate("date_of_birth"));
			e.setPhone(rs.getString("phone"));
			e.setAddress(rs.getString("address"));
			e.setDepartmentName(rs.getString("department_name"));
			e.setRemark(rs.getString("remark"));
			list.add(e);
		}
		rs.close();
		stm.close();
		return list;
	}

	public List<Employee> searchLastName(String searchValue) throws SQLException {
		Connection conn = DBUtil.makeConnection();
		PreparedStatement stm = conn.prepareStatement("SELECT [employee_id]\n" + "      ,[first_name]\n"
				+ "		 ,[last_name]\n" + "      ,[gender]\n" + "      ,[date_of_birth]\n" + "      ,[phone]\n"
				+ "      ,[address]\n" + "      ,[department_name]\n" + "      ,[remark]\n"
				+ "  FROM [JWD_Assignment_01].[dbo].[Employee] where last_name like ?");
		stm.setString(1, "%" + searchValue + "%");
		ResultSet rs = stm.executeQuery();
		ArrayList<Employee> list = new ArrayList<>();
		while (rs.next()) {
			Employee e = new Employee();
			e.setEmployeeId(rs.getInt("employee_id"));
			e.setFirstName(rs.getString("first_name"));
			e.setLastName(rs.getString("last_name"));
			e.setGender(rs.getBoolean("gender"));
			e.setDob(rs.getDate("date_of_birth"));
			e.setPhone(rs.getString("phone"));
			e.setAddress(rs.getString("address"));
			e.setDepartmentName(rs.getString("department_name"));
			e.setRemark(rs.getString("remark"));
			list.add(e);
		}
		rs.close();
		stm.close();
		return list;
	}

	public boolean addAnEmployee(String firstName, String lastName, int gender, java.util.Date dob, String phone, String address,
			String departmentName, String remark) throws SQLException {
		PreparedStatement stm = null;
		Connection con = DBUtil.makeConnection();
		try {
			if (con != null) {
				String sql = "Insert Into Employee(first_name, last_name, gender, date_of_birth, phone, address, department_name, remark) Values(?,?,?,?,?,?,?,?)";
				stm = con.prepareStatement(sql);
				stm.setString(1, firstName);
				stm.setString(2, lastName);
				stm.setInt(3, gender);
				stm.setDate(4, (java.sql.Date) dob);
				stm.setString(5, phone);
				stm.setString(6, address);
				stm.setString(7, departmentName);
				stm.setString(8, remark);
				int row = stm.executeUpdate();

				if (row > 0) {
					return true;
				}
			}
		} finally {
			if (con != null) {
				con.close();
			}
			if (stm != null) {
				stm.close();
			}
		}
		return false;
	}

	public static void main(String[] args) throws SQLException {
		EmployeeDao dao = new EmployeeDao();
//		List<Employee> list = dao.searchLastName("k");
//		for (Employee e : list) {
//			System.out.println(e + "\n");
//		}
		
		dao.addAnEmployee("minh", "tran", 1, new Date(1992-02-12), "0936258258", "District 10", "service", "no comment");
	}
}
