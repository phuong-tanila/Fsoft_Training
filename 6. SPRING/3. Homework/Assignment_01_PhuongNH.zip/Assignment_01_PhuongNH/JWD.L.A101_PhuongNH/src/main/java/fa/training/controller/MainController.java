package fa.training.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MainController
 */
@WebServlet("/maincontroller")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String LOGIN_PAGE = "login.jsp";
	private final String LOGIN_CONTROLLER = "/logincontroller";
	private final String SEARCH_CONTROLLER = "/searchcontroller";
	private final String ADD_CONTROLLER = "/addemployeecontroller";
	private final String NULL_CONTROLLER = "/nullcontroller";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MainController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String op = request.getParameter("op");
		String url = LOGIN_PAGE;
		PrintWriter out = response.getWriter();
		try {
			if (op == null) {
				url = NULL_CONTROLLER;
			} else {
				switch (op) {
				case "Login": {
					url = LOGIN_CONTROLLER;
					break;
				}
				case "Search": {
					url = SEARCH_CONTROLLER;
					break;
				}
				case "Add": {
					url = ADD_CONTROLLER;
					break;
				}
				}

			}

		} finally {
			request.getRequestDispatcher(url).forward(request, response);
			out.close();
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException ex) {
			Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException ex) {
			Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

}
