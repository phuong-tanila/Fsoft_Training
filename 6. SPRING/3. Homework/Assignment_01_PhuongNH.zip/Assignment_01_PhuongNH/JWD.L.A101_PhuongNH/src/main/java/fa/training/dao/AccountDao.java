package fa.training.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import fa.training.utils.DBUtil;

public class AccountDao implements Serializable {

	public boolean checkLogin(String account, String password) throws SQLException, NamingException {
		Connection con = null;
		PreparedStatement stm = null;
		ResultSet rs = null;

		try {
			con = DBUtil.makeConnection();
			if (con != null) {
				String sql = "Select account from Account" + " where account = ? " + "and password = ?";
				stm = con.prepareStatement(sql);
				stm.setString(1, account);
				stm.setString(2, password);
				rs = stm.executeQuery();
				if (rs.next()) {
					return true;
				}
			}

		} finally {
			if (con != null) {
				con.close();
			}
			if (stm != null) {
				stm.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return false;
	}
}
