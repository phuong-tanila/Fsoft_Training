package fa.training.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fa.training.dao.EmployeeDao;
import fa.training.entities.Employee;

/**
 * Servlet implementation class SearchController
 */
@WebServlet("/searchcontroller")
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String EMPLOYEE_MANAGEMENT_PAGE = "/views/employeeManagement.jsp";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String url = null;
		String searchValue = request.getParameter("valueSearch");
		try {
			EmployeeDao dao = new EmployeeDao();
			List<Employee> result = dao.searchLastName(searchValue);
			if(result != null) {
				request.setAttribute("list", result);
			}else {
				request.setAttribute("msg", "No matches!!!");
			}
			url = EMPLOYEE_MANAGEMENT_PAGE;
			request.getRequestDispatcher(url).forward(request, response);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			out.close();
		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException ex) {
			Logger.getLogger(SearchController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException ex) {
			Logger.getLogger(SearchController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

}
