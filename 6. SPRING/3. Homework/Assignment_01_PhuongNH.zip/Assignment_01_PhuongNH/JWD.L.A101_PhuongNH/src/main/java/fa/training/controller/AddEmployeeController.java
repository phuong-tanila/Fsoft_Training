package fa.training.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fa.training.dao.EmployeeDao;
import fa.training.entities.Account;
import fa.training.entities.Employee;
import fa.training.utils.DateUtils;

/**
 * Servlet implementation class AddEmployeeController
 */
@WebServlet("/addemployeecontroller")
public class AddEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final String EMPLOYEE_MANAGEMENT_PAGE = "/views/employeeManagement.jsp";
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddEmployeeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String phone = request.getParameter("phone");
		int gender = Integer.parseInt(request.getParameter("gender"));
		String account = request.getParameter("account");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String address = request.getParameter("address");
		int status = Integer.parseInt(request.getParameter("status"));
		String department = request.getParameter("department");
		String remark = request.getParameter("remark");
		Date dob = null;
		try {
			dob = DateUtils.convertStringToDate(request.getParameter("dob"));
		} catch (ParseException e) {
			e.printStackTrace();
		}

		Account acc = new Account();
		EmployeeDao dao = new EmployeeDao();
		try {
			if (dao.addAnEmployee(firstName, lastName, gender, dob, phone, address, department, remark)) {
				request.getRequestDispatcher(EMPLOYEE_MANAGEMENT_PAGE).forward(request, response);
			}else {
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException ex) {
			Logger.getLogger(SearchController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (SQLException ex) {
			Logger.getLogger(SearchController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

}
