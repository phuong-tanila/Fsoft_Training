package com.example.frontend.controller;

import com.example.frontend.entities.AppUser;
import com.example.frontend.request.AppUserDTO;
import com.example.frontend.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping(value = "/register-user")
	public AppUser save(@RequestBody AppUserDTO user) throws Exception {
		return userService.registerUserAccount(user);
	}

}
