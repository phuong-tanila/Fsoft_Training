package com.example.frontend.services;

import com.example.frontend.dao.AppUserRepository;
import com.example.frontend.entities.AppUser;
import com.example.frontend.request.AppUserDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	@Autowired
	private AppUserRepository appUserRepository;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	// ...
	public AppUser registerUserAccount(AppUserDTO userDto) throws Exception {
		AppUser user = new AppUser();
		
		user.setUserName(userDto.getUserName());
		user.setEnabled(true);
		user.setEncryptedPassword(bCryptPasswordEncoder.encode(userDto.getPassword()));
		
		appUserRepository.save(user);
		return user;
	}
}
