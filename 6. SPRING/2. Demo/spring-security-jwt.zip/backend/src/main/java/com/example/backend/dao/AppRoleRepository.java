package com.example.backend.dao;

import com.example.backend.entities.AppRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AppRoleRepository extends JpaRepository<AppRole, Long> {
	@Query("SELECT a.roleName FROM AppRole a "
			+ "LEFT JOIN AppUserRole b ON a.roleId = b.appRole.roleId "
			+ "WHERE b.appUser.userId =?1")
	List<String> findByRoleName(Long userId);
}
