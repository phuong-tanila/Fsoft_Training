package com.example.backend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.backend.entities.WeatherInfo;

@RestController
@RequestMapping("/api/weather")
public class WeatherController {
	@Autowired
	private RestTemplate restTemplate;
	@Value("${weather.api.url}")
	private String apiUrl;
	@Value("${weather.api.key}")
	private String apiKey;

	@GetMapping("")
	public WeatherInfo getWeatherInfo(@RequestParam("city") String city) {
		String url = apiUrl + "?q=" + city + "&appid=" + apiKey;
		System.out.print("abc");
		return restTemplate.getForObject(url, WeatherInfo.class);
	}
}
