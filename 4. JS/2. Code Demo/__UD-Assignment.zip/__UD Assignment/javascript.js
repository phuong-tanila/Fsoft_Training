var products = [
    {
        "id": 1,
        "image": "image/product.jpg",
        "name": "MASSA AST",
        "color": "Black",
        "material": "metal",
        "price": 120.00,
        "discount": 25.00,
        "quantity": 1,
    },
    {
        "id": 2,
        "image": "image/product.jpg",
        "name": "MASSA AST",
        "color": "Black",
        "material": "metal",
        "price": 7.00,
        "discount": 0.00,
        "quantity": 1
    },
    {
        "id": 3,
        "image": "image/product.jpg",
        "name": "MASSA AST",
        "color": "Black",
        "material": "metal",
        "price": 120.00,
        "discount": 25.00,
        "quantity": 1
    }
]

loadProduct();


function loadProduct() {
    let totalPrice = 0;
    let totalTax = 0;
    let totalDiscount = 0;
    let content = ` 
    <table class="table table-bordered">
        <thead>
            <tr>
            <th>Product</th>
            <th>Description</th>
            <th>Quantity/Update</th>
            <th>Price</th>
            <th>Discount</th>
            <th>Tax</th>
            <th>Total</th>
            </tr>
        </thead>
        <tbody>
    `;
    for (const product of products) {
        let discount = product.discount == 0 ? '--' : '$' + product.discount;
        let tax = getTax(product.quantity, product.price);
        let total = getTotalPrice(product.quantity, product.price, product.discount, tax);
        totalPrice += total;
        totalDiscount += product.discount;
        totalTax += tax;
        content += `
        <tr>
        <td><img class="table-image" src="${product.image}" alt="" /></td>
        <td>${product.name}<br/>Color : ${product.color}, Material : ${product.material}</td>
        <td>
            <div class="table-quantity">
                <input type="number" name="quantity" value="${product.quantity}" readonly class="quantity" id="quantity-${product.id}" />
                <button type="button" class="table-btn remove" onclick="removeQuantity(${product.id})" >
                    <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="table-btn add" onclick="addQuantity(${product.id})">
                    <i class="fas fa-plus"></i>
                </button>
                <button type="button" class="table-btn delete" onclick="deleteProduct(${product.id})">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </td>
        <td id="price-${product.id}">$${product.price}</td>
        <td id="discount-${product.id}">${discount}</td>
        <td class="tax" id="tax-${product.id}">$${tax}</td>
        <td class="total-price" id="total-${product.id}" onchange="">$${total}</td>
        </tr>
        `;
    }

    content += ` 
    <tr>
        <td colspan="6" style="text-align: right;">Total Price</td>
        <td id="totalPrice">$${totalPrice}</td>
        </tr>
        <tr>
        <td colspan="6" style="text-align: right;">Total Discount</td>
        <td id="totalDiscount">$${totalDiscount}</td>
        </tr>
        <tr>
            <td colspan="6" style="text-align: right;">Total Tax</td>
            <td id="totalTax">$${totalTax}</td>
        </tr> 
    `;
    content += `
        </tbody>
    </table>`;
    document.getElementById("content").innerHTML = content;
}



function getTotalPrice() {
    return products.reduce((totalPrice, currentProduct) => {
        return totalPrice + getTotalPrice(currentProduct.quantity, currentProduct.price, currentProduct.discount, getTax(currentProduct.quantity, currentProduct.price))
    }, 0)
}


function addQuantity(id) {
    let product = products.find(e => e.id === id);
    product.quantity++;
    loadProduct()
}


function removeQuantity(id) {
    let product = products.find(e => e.id === id);
    if (product.quantity - 1 === 0)
        return
    product.quantity--;
    loadProduct();
}

function deleteProduct(id) {
    products = products.filter(e => e.id !== id)
    loadProduct();
}


function getTax(quantity, price) {
    return quantity * price * 12.5 / 100;
}

function getTotalPrice(quantity, price, discount, tax) {
    if (isNaN(discount)) {
        discount = 0;
    }
    return quantity * price - discount + tax;
}



