package fa.training.problem02;

import java.util.ArrayList;
import java.util.Collections;

public class SpecialSort {
	public String sort(ArrayList arr) {
		Collections.sort(arr, new EvenOddComparator());
		return arr.toString();
	}
}
