package fa.training.problem01;

public class QuadraticEquation {
	private int a;
	private int b;
	private int c;
	
	public int NumberOfRootQuadraticEquation(int a, int b ,int c) {
		int del = (b*b) - 4*a*c;
		
		if(a == 0 && b==0 && c==0) {
			return 3;
		}else if(a == 0) {
            if (b == 0) {
                System.out.println("Phương trình vô nghiệm!");
            } else {
                System.out.println("Phương trình có một nghiệm: "
                        + "x = " + (-c / b));
                return 1;
            }
            return 0;
		}else if(del == 0) {
			double x =(int) (-b)/(2*a);
			System.out.println("Phuong trinh co 1 nghiem x: " + x);
			return (int) 1;
		}else if(del > 0) {
			double x1 = (-b + Math.sqrt(del) / (2*a));
			double x2 = (-b - Math.sqrt(del) / (2*a));
			System.out.println("Phuong trinh co 2 nghiem x1: "+ x1 + " x2: "+ x2);
			return (int) 2;
		}
		return 0;
	}
	
}
